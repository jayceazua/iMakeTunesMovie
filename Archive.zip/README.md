# iMakeTunesMovie

### Josecarlos "Jayce" Azua || jayce.azua@students.makeschool.com
***
## Instruction to run Web App
* Follow this link [click here for the deployed app](https://thawing-basin-21835.herokuapp.com/)
1. ```$ git clone git@github.com:jayceazua/iMakeTunesMovie.git``` to your local desktop
2. ```$ cd iMakeTunesMovie```
3. run ```$ npm install``` on the command line
4. If you have nodemon installed on the command line run ```$ nodemon```
5. If you do not have nodemon, run ```$ node server.js``` from the root.

***
#### Number Hours Spent: ```2 hours and 40 minutes almost 3 hours```
***
#### Notes
I tried to locate the link for the iTunes Store link of the individual movies
